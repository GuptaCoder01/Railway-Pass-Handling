
	<div class="copy-right"> 
		<div class="container">
			<p>© Railway Pass Handling</p>
		</div> 
	</div> 
	<!-- //footer -->   
	