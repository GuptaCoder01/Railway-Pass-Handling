How to run the Rail Pass Handling (rpms) Project

1. Download the zip file

2. Extract the file and copy rpms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/HTML)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name rpmsdb

6. Import rpmsdb.sql file(given inside the zip package in the SQL file folder)

7. Run the script http://localhost/rpms

Credential for Admin panel :

Username: admin
Password: Test@123

Already Created Pass No: 305788314


